"""
Handle System SDK for Python

Author: zao
Version: 2.0.0
"""

import os
import json
import time
import base64
import tempfile
import logging
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass

import requests
import urllib3
import jks
import xmltodict
from zeep import Client, Transport
from cryptography.hazmat.primitives.serialization.pkcs12 import (
    load_key_and_certificates,
)
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.x509 import load_der_x509_certificate, load_pem_x509_certificate

# Disable SSL warnings for development (can be controlled by HANDLE_TLS_INSECURE)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class HandleSystemConfig:
    """Configuration for Handle System instance"""

    ip: str
    prefix: str
    port: int
    ssl_keystore_password: str
    ssl_truststore_password: str
    app_handle_id: str
    app_key_pwd: str
    app_verify_password: str

    @property
    def base_url(self) -> str:
        """Get the base HTTPS URL for the Handle System"""
        return f"https://{self.ip}:{self.port}/handleSystem"

    @property
    def lhs_prefix(self) -> str:
        """Get the Local Handle Service prefix"""
        return f"0.NA/{self.prefix}"


class HandleSystemError(Exception):
    """Base exception for Handle System operations"""

    pass


class HandleConnectionError(HandleSystemError):
    """Raised when connection to Handle System fails"""

    pass


class HandleAuthenticationError(HandleSystemError):
    """Raised when authentication fails"""

    pass


class HandleOperationError(HandleSystemError):
    """Raised when Handle operation fails"""

    pass


class CertificateManager:
    """Manages SSL certificates for Handle System authentication"""

    def __init__(
        self, config: HandleSystemConfig, cert_base_path: Optional[str] = None
    ):
        self.config = config
        self.cert_base_path = self._resolve_cert_path(config, cert_base_path)

        # Certificate file paths - check for custom paths first
        prefix_upper = config.prefix.replace(".", "_").upper()
        self.keystore_path = os.getenv(
            f"HANDLE_{prefix_upper}_KEYSTORE_PATH"
        ) or os.path.join(self.cert_base_path, "local.keystore")
        self.truststore_path = os.getenv(
            f"HANDLE_{prefix_upper}_TRUSTSTORE_PATH"
        ) or os.path.join(self.cert_base_path, "localTrust.keystore")

        # Additional files used for app credentials (Java Util expects these locations)
        # collection.cer lives under cdi/, appPrivateKey.pfx lives one level above cdi/
        def _resolve_or_env(env_key: str, default_path: str) -> str:
            return os.getenv(env_key) or default_path

        # Default paths for root-layout (no cdi folder)
        root_prefix_dir = os.path.join(os.getcwd(), config.prefix)

        # collection.cer priority: env → root-layout → current base dir
        self.collection_cer_path = _resolve_or_env(
            f"HANDLE_{prefix_upper}_COLLECTION_CER_PATH",
            next(
                (
                    p
                    for p in [
                        os.path.join(root_prefix_dir, "collection.cer"),
                        os.path.join(self.cert_base_path, "collection.cer"),
                    ]
                    if os.path.exists(p)
                ),
                os.path.join(self.cert_base_path, "collection.cer"),
            ),
        )

        # pfx priority: env → root-layout → parent of base
        self.pfx_path = _resolve_or_env(
            f"HANDLE_{prefix_upper}_PFX_PATH",
            next(
                (
                    p
                    for p in [
                        os.path.join(root_prefix_dir, "appPrivateKey.pfx"),
                        os.path.join(
                            os.path.dirname(self.cert_base_path), "appPrivateKey.pfx"
                        ),
                    ]
                    if os.path.exists(p)
                ),
                os.path.join(os.path.dirname(self.cert_base_path), "appPrivateKey.pfx"),
            ),
        )
        self.pfx_password = (
            os.getenv(f"HANDLE_{prefix_upper}_PFX_PASSWORD") or config.app_key_pwd
        )

        # Temporary PEM files
        self._temp_cert_file: Optional[str] = None
        self._temp_key_file: Optional[str] = None
        self._temp_ca_file: Optional[str] = None

    def _resolve_cert_path(
        self, config: HandleSystemConfig, cert_base_path: Optional[str]
    ) -> str:
        """Resolve certificate directory path; support root-level `<cwd>/<prefix>` and env/template overrides only."""

        # Helper to validate a candidate prefix directory
        def _is_prefix_dir(path: str) -> bool:
            return os.path.isdir(path) and (
                os.path.exists(os.path.join(path, "local.keystore"))
                or os.path.exists(os.path.join(path, "localTrust.keystore"))
            )

        # 1) If explicit base path provided, try to use it directly or with prefix
        if cert_base_path:
            if _is_prefix_dir(cert_base_path):
                return cert_base_path
            maybe = os.path.join(cert_base_path, config.prefix)
            return maybe

        # 2) If template provided, try formatted path
        path_template = os.getenv("HANDLE_CERT_PATH_TEMPLATE")
        if path_template:
            templated = path_template.format(prefix=config.prefix)
            return templated

        # 3) Autodetect root-level layout only
        cwd = os.getcwd()
        candidate = os.path.join(cwd, config.prefix)
        if _is_prefix_dir(candidate):
            return candidate

        # 4) Final default to root-level `<cwd>/<prefix>`
        return candidate

    def get_certificate_info(self) -> Dict[str, Any]:
        """Get information about certificate files and paths"""
        return {
            "base_path": self.cert_base_path,
            "keystore": {
                "path": self.keystore_path,
                "exists": os.path.exists(self.keystore_path),
                "size": (
                    os.path.getsize(self.keystore_path)
                    if os.path.exists(self.keystore_path)
                    else 0
                ),
            },
            "truststore": {
                "path": self.truststore_path,
                "exists": os.path.exists(self.truststore_path),
                "size": (
                    os.path.getsize(self.truststore_path)
                    if os.path.exists(self.truststore_path)
                    else 0
                ),
            },
            "collection_cer": {
                "path": self.collection_cer_path,
                "exists": os.path.exists(self.collection_cer_path),
                "size": (
                    os.path.getsize(self.collection_cer_path)
                    if os.path.exists(self.collection_cer_path)
                    else 0
                ),
            },
            "pfx": {
                "path": self.pfx_path,
                "exists": os.path.exists(self.pfx_path),
                "size": (
                    os.path.getsize(self.pfx_path)
                    if os.path.exists(self.pfx_path)
                    else 0
                ),
            },
        }

    def _validate_certificate_files(self) -> None:
        """Validate that required certificate files exist"""
        if not os.path.exists(self.keystore_path):
            raise HandleAuthenticationError(f"Keystore not found: {self.keystore_path}")
        if not os.path.exists(self.truststore_path):
            raise HandleAuthenticationError(
                f"Truststore not found: {self.truststore_path}"
            )

    def extract_certificates(self) -> bool:
        """Extract certificates from JKS files to PEM format"""
        try:
            self._validate_certificate_files()

            # Load keystore and truststore
            keystore = jks.KeyStore.load(
                self.keystore_path, self.config.ssl_keystore_password
            )
            truststore = jks.KeyStore.load(
                self.truststore_path, self.config.ssl_truststore_password
            )

            logger.info(f"Loaded keystore with {len(keystore.entries)} entries")
            logger.info(f"Loaded truststore with {len(truststore.entries)} entries")

            # Extract client certificate and private key
            client_cert_der = None
            private_key_der = None

            for alias, entry in keystore.entries.items():
                if isinstance(entry, jks.PrivateKeyEntry):
                    # Decrypt private key with key password (often equals keystore password)
                    try:
                        entry.decrypt(self.config.ssl_keystore_password)
                    except Exception as decrypt_err:
                        raise HandleAuthenticationError(
                            f"Failed to decrypt private key for alias '{alias}': {decrypt_err}"
                        )
                    client_cert_der = entry.cert_chain[0][1]
                    private_key_der = entry.pkey_pkcs8
                    logger.debug(f"Found client certificate/private key: {alias}")
                    break

            if not client_cert_der or not private_key_der:
                raise HandleAuthenticationError(
                    "Client certificate or private key not found in keystore"
                )

            # Extract CA certificates
            ca_certs_der = []
            for alias, entry in truststore.entries.items():
                if isinstance(entry, jks.TrustedCertEntry):
                    ca_certs_der.append(entry.cert)
                    logger.debug(f"Found CA certificate: {alias}")

            # Convert to PEM format
            self._create_pem_files(client_cert_der, private_key_der, ca_certs_der)

            return True

        except Exception as e:
            logger.error(f"Certificate extraction failed: {e}")
            raise HandleAuthenticationError(f"Failed to extract certificates: {e}")

    def _create_pem_files(
        self, cert_der: bytes, key_der: bytes, ca_certs_der: List[bytes]
    ) -> None:
        """Create temporary PEM files from DER data"""
        try:
            from cryptography import x509
            from cryptography.hazmat.primitives import serialization

            # Convert client certificate from DER to PEM using cryptography
            cert_obj = x509.load_der_x509_certificate(cert_der)
            cert_pem = cert_obj.public_bytes(serialization.Encoding.PEM)

            with tempfile.NamedTemporaryFile(
                mode="wb", delete=False, suffix=".pem"
            ) as f:
                f.write(cert_pem)
                self._temp_cert_file = f.name

            # Convert private key from DER to PEM using cryptography (PKCS8 expected)
            key_obj = serialization.load_der_private_key(key_der, password=None)

            key_pem = key_obj.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )

            with tempfile.NamedTemporaryFile(
                mode="wb", delete=False, suffix=".pem"
            ) as f:
                f.write(key_pem)
                self._temp_key_file = f.name

            # Convert CA certificates from DER to PEM
            with tempfile.NamedTemporaryFile(
                mode="wb", delete=False, suffix=".pem"
            ) as f:
                for cert_der in ca_certs_der:
                    ca_cert_obj = x509.load_der_x509_certificate(cert_der)
                    ca_cert_pem = ca_cert_obj.public_bytes(serialization.Encoding.PEM)
                    f.write(ca_cert_pem)
                self._temp_ca_file = f.name

            # PEM files created for requests/zeep to consume

        except Exception as crypto_error:
            logger.error(f"Certificate conversion failed: {crypto_error}")
            raise HandleAuthenticationError(
                f"Failed to convert certificates: {crypto_error}"
            )

    def _load_x509_auto(self, path: str):
        raw = open(path, "rb").read()
        try:
            return load_pem_x509_certificate(raw)
        except ValueError:
            return load_der_x509_certificate(raw)

    def generate_app_credentials(self, app_handle_id: str) -> Tuple[str, str]:
        """Replicate Java Util: RSA encrypt (PKCS1 v1.5) and sign (SHA1withRSA) the ciphertext.

        Returns (appHandleIdEncryptBase64, appHandleIdSignBase64)
        """
        if not os.path.exists(self.collection_cer_path):
            raise HandleAuthenticationError(
                f"collection.cer not found: {self.collection_cer_path}"
            )
        if not os.path.exists(self.pfx_path):
            raise HandleAuthenticationError(
                f"appPrivateKey.pfx not found: {self.pfx_path}"
            )

        # said = RSAEncrypt.encrypt(cer, (appHandleId + "12345678"))
        cert = self._load_x509_auto(self.collection_cer_path)
        public_key = cert.public_key()
        plaintext = (app_handle_id + "12345678").encode("utf-8")
        ciphertext = public_key.encrypt(plaintext, padding.PKCS1v15())
        enc_b64 = base64.b64encode(ciphertext).decode("ascii")

        # snaid = RSASignature.sign(pfx, keyPwd, said)  // SHA1withRSA over ciphertext
        pfx_bytes = open(self.pfx_path, "rb").read()
        private_key, _, _ = load_key_and_certificates(
            pfx_bytes, self.pfx_password.encode("utf-8")
        )
        signature = private_key.sign(ciphertext, padding.PKCS1v15(), hashes.SHA1())
        sig_b64 = base64.b64encode(signature).decode("ascii")

        return enc_b64, sig_b64

    # SSLContext management removed; requests uses PEM paths directly

    def get_cert_files(self) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """Get paths to temporary certificate files"""
        return self._temp_cert_file, self._temp_key_file, self._temp_ca_file

    def cleanup(self) -> None:
        """Clean up temporary certificate files"""
        for temp_file in [
            self._temp_cert_file,
            self._temp_key_file,
            self._temp_ca_file,
        ]:
            if temp_file and os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                    logger.debug(f"Cleaned up temporary file: {temp_file}")
                except OSError:
                    pass


class HandleSystemClient:
    """Main client for Handle System operations"""

    def __init__(
        self, config: HandleSystemConfig, cert_base_path: Optional[str] = None
    ):
        """
        Initialize Handle System client

        Args:
            config: Handle system configuration
            cert_base_path: Optional path to certificate directory
        """
        self.config = config
        self.cert_manager = CertificateManager(config, cert_base_path)

        # Create HTTP session with SSL configuration
        self._session = self._create_session()

        logger.info(
            f"Initialized Handle client for {config.prefix} at {config.base_url}"
        )

    def _create_session(self) -> requests.Session:
        """Create HTTP session with proper SSL configuration"""
        session = requests.Session()

        try:
            # Extract certs/keys from JKS to PEM temp files
            has_certs = self.cert_manager.extract_certificates()
            cert_file, key_file, ca_file = self.cert_manager.get_cert_files()

            # Configure client certificate authentication
            if has_certs and cert_file and key_file:
                session.cert = (cert_file, key_file)
                logger.debug("Session configured with client certificates")

            # Configure server certificate verification
            # Default mirrors Java behavior (disable CN check). If HANDLE_TLS_INSECURE=true (default), disable verification.
            insecure = os.getenv("HANDLE_TLS_INSECURE", "true").lower() in (
                "1",
                "true",
                "yes",
            )
            if insecure:
                session.verify = False
            else:
                # If CA bundle extracted, use it; otherwise fall back to default True
                session.verify = ca_file if ca_file else True

            # Per-request timeouts are set on zeep Transport (not on session)

            logger.debug("Session configured with client certificates")

        except Exception as e:
            logger.warning(f"SSL configuration failed: {e}, using fallback")
            session.verify = False
            # Per-request timeouts are set on zeep Transport (not on session)

        # Configure headers for Handle System compatibility
        session.headers.update(
            {
                "User-Agent": "HandleSDK/2.0.0 Python",
                "Accept": "application/xml, text/xml, application/soap+xml",
                "Content-Type": "text/xml; charset=utf-8",
                "Connection": "keep-alive",
            }
        )

        return session

    def _create_soap_client(self, service_name: str) -> Client:
        """Create SOAP client for specific service"""
        wsdl_url = f"{self.config.base_url}/service/{service_name}?wsdl"

        try:
            # Create transport with timeouts
            transport = Transport(
                session=self._session, timeout=30, operation_timeout=30
            )

            # Create SOAP client with Handle System specific settings
            client = Client(wsdl_url, transport=transport)

            logger.debug(f"Created SOAP client for {service_name} at {wsdl_url}")
            return client

        except Exception as e:
            logger.error(f"SOAP client creation failed for {service_name}: {e}")
            # Try with more permissive settings
            try:
                logger.debug("Attempting fallback SOAP client creation...")
                transport = Transport(session=self._session, timeout=60)
                client = Client(wsdl_url, transport=transport)
                logger.debug(f"Created fallback SOAP client for {service_name}")
                return client
            except Exception as fallback_error:
                raise HandleConnectionError(
                    f"Failed to create SOAP client for {service_name}. "
                    f"Primary error: {e}, Fallback error: {fallback_error}"
                )

    def _xml_to_dict(self, xml_string: str) -> Dict[str, Any]:
        """Convert XML response to dictionary"""
        try:
            return xmltodict.parse(xml_string)
        except Exception as e:
            logger.warning(f"XML parsing failed: {e}")
            return {"raw_xml": xml_string, "parse_error": str(e)}

    def _generate_credentials(self) -> Tuple[str, str]:
        """Generate credentials matching Java Util (RSA encrypt + SHA1withRSA sign)."""
        return self.cert_manager.generate_app_credentials(self.config.app_handle_id)

    def parse_handle(
        self, handle_id: str, authentication: bool = False
    ) -> Dict[str, Any]:
        """
        Parse (resolve) a Handle to retrieve its metadata

        Args:
            handle_id: The Handle identifier to resolve
            authentication: Whether to use authentication

        Returns:
            Dictionary containing the handle resolution result

        Raises:
            HandleOperationError: If the operation fails
        """
        try:
            client = self._create_soap_client("HandleParseService")

            is_auth = "1" if authentication else "0"
            result = client.service.handleParse([handle_id], is_auth)

            logger.info(f"Successfully resolved handle: {handle_id}")
            return {
                "success": True,
                "handle_id": handle_id,
                "data": self._xml_to_dict(result),
                "raw_xml": result,
            }

        except Exception as e:
            logger.error(f"Handle parsing failed for {handle_id}: {e}")
            raise HandleOperationError(f"Failed to parse handle {handle_id}: {e}")

    def register_handle(
        self, handle_id: str, target_url: str, metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Register a new Handle

        Args:
            handle_id: The Handle identifier to register
            target_url: The target URL the handle should resolve to
            metadata: Optional additional metadata

        Returns:
            Dictionary containing the registration result

        Raises:
            HandleOperationError: If the operation fails
        """
        try:
            client = self._create_soap_client("Register/registerService")

            # Create registration XML
            xml_data = self._create_registration_xml(
                handle_id, target_url, metadata or {}
            )

            # Generate authentication credentials
            encrypted_id, signature = self._generate_credentials()

            # Call registration service
            result = client.service.handleRegistry(
                xml=xml_data,
                adminHandleId=self.config.lhs_prefix,
                adminIndex="300",
                appHandleId=self.config.app_handle_id,
                appHandleIdEncryptBase64=encrypted_id,
                appHandleIdSignBase64=signature,
                password=self.config.app_verify_password,
                operationTime=str(int(time.time() * 1000)),
            )

            logger.info(f"Successfully registered handle: {handle_id}")
            return {
                "success": True,
                "handle_id": handle_id,
                "data": self._xml_to_dict(result),
                "raw_xml": result,
            }

        except Exception as e:
            logger.error(f"Handle registration failed for {handle_id}: {e}")
            raise HandleOperationError(f"Failed to register handle {handle_id}: {e}")

    def search_handles(
        self,
        query_fields: List[str],
        query_values: List[str],
        query_relations: List[str],
        start: int = 0,
    ) -> Dict[str, Any]:
        """
        Search for Handles based on metadata

        Args:
            query_fields: List of metadata fields to search
            query_values: List of values to search for
            query_relations: List of relations (e.g., "=", "like")
            start: Starting position for results

        Returns:
            Dictionary containing the search results

        Raises:
            HandleOperationError: If the operation fails
        """
        try:
            client = self._create_soap_client("HandleSearchService")

            result = client.service.searchData(
                queryPoint=query_fields,
                queryValue=query_values,
                queryRelation=query_relations,
                metedataStandard="DC",
                start=start,
            )

            logger.info(f"Handle search completed with {len(query_fields)} criteria")
            return {
                "success": True,
                "query": {
                    "fields": query_fields,
                    "values": query_values,
                    "relations": query_relations,
                },
                "data": self._xml_to_dict(result),
                "raw_xml": result,
            }

        except Exception as e:
            logger.error(f"Handle search failed: {e}")
            raise HandleOperationError(f"Handle search failed: {e}")

    def _create_registration_xml(
        self, handle_id: str, target_url: str, metadata: Dict[str, Any]
    ) -> str:
        """Create XML matching CDI Handle schema (see book.xml)."""

        # Build <metadata> children from provided metadata dict and target_url
        def sanitize_tag(name: str) -> str:
            import re

            return re.sub(r"[^a-zA-Z0-9_]", "_", str(name)).lower()

        meta_parts = []
        if target_url:
            meta_parts.append(
                f"      <url><value><![CDATA[{target_url}]]></value></url>"
            )
        for k, v in (metadata or {}).items():
            tag = sanitize_tag(k)
            meta_parts.append(f"      <{tag}><value><![CDATA[{v}]]></value></{tag}>")

        metedata_standard = f"{self.config.prefix}/metadatastandard.book"

        xml = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<root xmlns="http://www.cdi.cn/handle" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n'
            f'  <ListRecords metedataStandard="{metedata_standard}">\n'
            "    <record>\n"
            "      <header>\n"
            f"        <identifier>{handle_id}</identifier>\n"
            "        <metadataOption>0</metadataOption>\n"
            "      </header>\n"
            "      <metadata>\n"
            + ("\n".join(meta_parts) + "\n" if meta_parts else "")
            + "      </metadata>\n"
            "    </record>\n"
            "  </ListRecords>\n"
            "</root>"
        )
        return xml

    # Removed test_connection utility to reduce surface area

    def get_certificate_status(self) -> Dict[str, Any]:
        """
        Get detailed certificate status and configuration

        Returns:
            Dictionary containing certificate paths, existence, and configuration info
        """
        cert_info = self.cert_manager.get_certificate_info()
        cert_files = self.cert_manager.get_cert_files()

        return {
            "configuration": {
                "prefix": self.config.prefix,
                "base_path": cert_info["base_path"],
                "resolved_paths": {
                    "keystore": cert_info["keystore"]["path"],
                    "truststore": cert_info["truststore"]["path"],
                    "collection_cer": cert_info["collection_cer"]["path"],
                    "pfx": cert_info["pfx"]["path"],
                },
            },
            "file_status": {
                "keystore": cert_info["keystore"],
                "truststore": cert_info["truststore"],
                "collection_cer": cert_info["collection_cer"],
                "pfx": cert_info["pfx"],
            },
            "ssl_status": {
                "temp_cert_file": cert_files[0],
                "temp_key_file": cert_files[1],
                "temp_ca_file": cert_files[2],
                "ssl_configured": all(cert_files),
            },
        }

    def close(self) -> None:
        """Clean up resources"""
        self.cert_manager.cleanup()
        self._session.close()
        logger.info("Handle client closed")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class HandleSDK:
    """High-level SDK interface for Handle System operations"""

    @staticmethod
    def _load_env_file(path: str = ".env") -> None:
        """Minimal .env loader (no external deps). Does not override existing envs."""
        try:
            if not path or not os.path.exists(path):
                return
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "=" not in line:
                        continue
                    key, val = line.split("=", 1)
                    key = key.strip()
                    val = val.strip().strip('"').strip("'")
                    if key and os.getenv(key) is None:
                        os.environ[key] = val
        except Exception:
            # Silently ignore .env parse errors to avoid breaking runtime
            pass

    @classmethod
    def from_env(cls, prefix: str) -> "HandleSystemClient":
        """
        Create client from environment variables

        Expected environment variables (replace PREFIX with actual prefix):
        - HANDLE_{PREFIX}_IP
        - HANDLE_{PREFIX}_PORT (optional, defaults to 8443)
        - HANDLE_{PREFIX}_SSL_KEYSTORE_PASSWORD
        - HANDLE_{PREFIX}_SSL_TRUSTSTORE_PASSWORD
        - HANDLE_{PREFIX}_APP_HANDLE_ID
        - HANDLE_{PREFIX}_APP_KEY_PWD
        - HANDLE_{PREFIX}_APP_VERIFY_PASSWORD
        """
        # Load .env if present (and not already loaded)
        cls._load_env_file(os.getenv("HANDLE_ENV_FILE", ".env"))

        prefix_upper = prefix.replace(".", "_").upper()

        # Load prefix-level JSON config if present (sdk.config.json or config.json under <cwd>/<prefix>/)
        def _load_prefix_config(prefix_str: str) -> Dict[str, Any]:
            base = os.path.join(os.getcwd(), prefix_str)
            for name in ("sdk.config.json", "config.json"):
                path = os.path.join(base, name)
                try:
                    if os.path.exists(path):
                        with open(path, "r", encoding="utf-8") as f:
                            return json.load(f) or {}
                except Exception:
                    continue
            return {}

        prefix_cfg = _load_prefix_config(prefix)

        # Ensure minimal config if not using .env: open a wizard in Jupyter to create sdk.config.json
        required_keys = [
            "ip",
            "ssl_keystore_password",
            "ssl_truststore_password",
            "app_handle_id",
            "app_key_pwd",
            "app_verify_password",
        ]
        if any(prefix_cfg.get(k) in (None, "") for k in required_keys):
            try:
                # Avoid importing twice; function is declared at module end
                if _is_jupyter_environment():  # type: ignore[name-defined]
                    try:
                        open_config_wizard(prefix)  # type: ignore[name-defined]
                    except Exception:
                        pass
                    raise ValueError(
                        f"Missing required settings for prefix '{prefix}'. "
                        f"A configuration wizard has been opened. Fill it and re-run."
                    )
            except Exception:
                # Non-jupyter or UI error: continue to normal env/JSON fallback which will raise below
                pass

        def get_value(env_key_suffix: str, cfg_key: str, required: bool = True, default: Any = None) -> Any:
            # Priority: ENV -> prefix config -> default
            env_key = f"HANDLE_{prefix_upper}_{env_key_suffix}"
            value = os.getenv(env_key)
            if value is None:
                value = prefix_cfg.get(cfg_key, default)
            if required and value is None:
                raise ValueError(
                    f"Missing required setting: ENV {env_key} or {prefix}/sdk.config.json key '{cfg_key}'"
                )
            return value

        config = HandleSystemConfig(
            ip=str(get_value("IP", "ip")),
            prefix=prefix,
            port=int(get_value("PORT", "port", required=False, default=8443)),
            ssl_keystore_password=str(get_value("SSL_KEYSTORE_PASSWORD", "ssl_keystore_password")),
            ssl_truststore_password=str(get_value("SSL_TRUSTSTORE_PASSWORD", "ssl_truststore_password")),
            app_handle_id=str(get_value("APP_HANDLE_ID", "app_handle_id")),
            app_key_pwd=str(get_value("APP_KEY_PWD", "app_key_pwd")),
            app_verify_password=str(get_value("APP_VERIFY_PASSWORD", "app_verify_password")),
        )

        cert_path = os.getenv("HANDLE_CERT_PATH")
        return HandleSystemClient(config, cert_path)

    @classmethod
    def create_client(
        cls,
        ip: str,
        prefix: str,
        ssl_keystore_password: str,
        ssl_truststore_password: str,
        app_handle_id: str,
        app_key_pwd: str,
        app_verify_password: str,
        port: int = 8443,
    ) -> "HandleSystemClient":
        """
        Create client with explicit configuration

        Args:
            ip: Handle system server IP
            prefix: Handle prefix
            ssl_keystore_password: Password for SSL keystore
            ssl_truststore_password: Password for SSL truststore
            app_handle_id: Application handle ID
            app_key_pwd: Application key password
            app_verify_password: Application verify password
            port: Server port (default: 8443)

        Returns:
            Configured HandleSystemClient instance
        """
        config = HandleSystemConfig(
            ip=ip,
            prefix=prefix,
            port=port,
            ssl_keystore_password=ssl_keystore_password,
            ssl_truststore_password=ssl_truststore_password,
            app_handle_id=app_handle_id,
            app_key_pwd=app_key_pwd,
            app_verify_password=app_verify_password,
        )

        return HandleSystemClient(config)


# Convenience functions
def parse_handle(
    handle_id: str, prefix: str = None, authentication: bool = False
) -> Dict[str, Any]:
    """
    Quick handle resolution using environment configuration

    Args:
        handle_id: Handle to resolve
        prefix: Handle system prefix (if None, extracted from handle_id)
        authentication: Whether to use authentication

    Returns:
        Resolution result dictionary
    """
    if prefix is None:
        prefix = handle_id.split("/")[0]

    with HandleSDK.from_env(prefix) as client:
        return client.parse_handle(handle_id, authentication)


def register_handle(
    handle_id: str,
    target_url: str,
    metadata: Optional[Dict[str, Any]] = None,
    prefix: str = None,
) -> Dict[str, Any]:
    """
    Quick handle registration using environment configuration

    Args:
        handle_id: Handle to register
        target_url: Target URL
        metadata: Optional metadata
        prefix: Handle system prefix (if None, extracted from handle_id)

    Returns:
        Registration result dictionary
    """
    if prefix is None:
        prefix = handle_id.split("/")[0]

    with HandleSDK.from_env(prefix) as client:
        return client.register_handle(handle_id, target_url, metadata)


__all__ = [
    "HandleSystemConfig",
    "HandleSystemClient",
    "HandleSDK",
    "HandleSystemError",
    "HandleConnectionError",
    "HandleAuthenticationError",
    "HandleOperationError",
    "parse_handle",
    "register_handle",
]

# ------------------------------
# Import-time helper: cert check + Jupyter upload UI
# ------------------------------

def _is_jupyter_environment() -> bool:
    try:
        from IPython import get_ipython  # type: ignore
        import sys as _sys
        shell = get_ipython()
        if not shell:
            return False
        return 'ipykernel' in _sys.modules
    except Exception:
        return False


def _any_cert_layout_present() -> bool:
    """Detect at least one valid root-level cert layout or env overrides.
    Layout: <cwd>/<prefix>/local.keystore and <cwd>/<prefix>/appPrivateKey.pfx
    """
    # 1) Env overrides
    try:
        for key, value in os.environ.items():
            if not key.startswith('HANDLE_'):
                continue
            if key.endswith('_KEYSTORE_PATH'):
                prefix_tag = key[len('HANDLE_'):-len('_KEYSTORE_PATH')]
                pfx_key = f'HANDLE_{prefix_tag}_PFX_PATH'
                keystore_exists = os.path.exists(value)
                pfx_exists = os.path.exists(os.getenv(pfx_key, ''))
                if keystore_exists and pfx_exists:
                    return True
    except Exception:
        pass

    # 2) Root-level scan
    try:
        cwd = os.getcwd()
        for name in os.listdir(cwd):
            prefix_dir = os.path.join(cwd, name)
            if not os.path.isdir(prefix_dir):
                continue
            if os.path.exists(os.path.join(prefix_dir, 'local.keystore')) and os.path.exists(os.path.join(prefix_dir, 'appPrivateKey.pfx')):
                return True
    except Exception:
        pass
    return False


def _show_cert_upload_dialog() -> None:
    """In Jupyter, render a simple dialog to upload cert bundle into proper layout."""
    try:
        import ipywidgets as widgets  # type: ignore
        from IPython.display import display  # type: ignore

        title = widgets.HTML(
            value=(
                '<div style="font-family:ui-sans-serif,system-ui;line-height:1.4">'
                '<h3 style="margin:4px 0 8px">Handle 证书初始化</h3>'
                '<p style="color:#555;margin:0 0 8px">未检测到证书文件，请上传到对应前缀目录（扁平布局）：</p>'
                '<ul style="margin:6px 0 10px 18px;color:#444">'
                '<li>local.keystore</li>'
                '<li>localTrust.keystore</li>'
                '<li>collection.cer</li>'
                '<li>appPrivateKey.pfx</li>'
                '</ul>'
                '</div>'
            )
        )

        prefix_input = widgets.Text(
            description='前缀',
            placeholder='例如 86.1009.24',
            layout=widgets.Layout(width='50%')
        )
        uploader = widgets.FileUpload(accept='', multiple=True)
        save_btn = widgets.Button(
            description='保存到本地',
            button_style='primary',
            layout=widgets.Layout(width='180px')
        )
        status = widgets.HTML(value='')

        def _save_clicked(_):
            from pathlib import Path
            prefix = prefix_input.value.strip()
            if not prefix:
                status.value = '<span style="color:#c00">请填写前缀，例如 86.1009.24</span>'
                return
            base = Path(os.getcwd()) / prefix
            try:
                base.mkdir(parents=True, exist_ok=True)
                expected = {
                    'local.keystore': base / 'local.keystore',
                    'localtrust.keystore': base / 'localTrust.keystore',
                    'collection.cer': base / 'collection.cer',
                    'appprivatekey.pfx': base / 'appPrivateKey.pfx',
                }
                saved = []
                unknown = []

                def _norm_name(n: str) -> str:
                    n = (n or '').replace('\\', '/').split('/')[-1]
                    return n.strip().lower()

                files = uploader.value
                iterable = []
                # ipywidgets FileUpload variations:
                # - v7: dict {filename: {content:bytes, ...}}
                # - v8: tuple/list of UploadedFile objects with .name/.content
                if isinstance(files, dict):
                    iterable = [(k, (v or {}).get('content')) for k, v in files.items()]
                elif isinstance(files, (list, tuple)):
                    for entry in files:
                        name = None
                        content = None
                        # UploadedFile object case (v8)
                        if hasattr(entry, 'name') and hasattr(entry, 'content'):
                            name = getattr(entry, 'name', None)
                            content = getattr(entry, 'content', None)
                        # dict-like fallback
                        elif isinstance(entry, dict):
                            name = entry.get('name') or entry.get('metadata', {}).get('name')
                            content = entry.get('content')
                        # mapping protocol fallback
                        else:
                            try:
                                name = entry['name']  # type: ignore[index]
                                content = entry['content']  # type: ignore[index]
                            except Exception:
                                name = None
                                content = None
                        if name is not None and content is not None:
                            iterable.append((name, content))
                else:
                    iterable = []

                for raw_name, content in iterable:
                    name = _norm_name(raw_name)
                    target = None
                    # direct match
                    if name in expected:
                        target = expected[name]
                    else:
                        # endswith match for nested paths or case variants
                        for k, v in expected.items():
                            if name.endswith(k):
                                target = v
                                break
                    if target and content:
                        with open(target, 'wb') as f:
                            f.write(content)
                        saved.append(str(target))
                    else:
                        unknown.append(raw_name)

                if not saved and not iterable:
                    status.value = '<span style="color:#c00">未接收到任何文件，请先选择文件再点击保存</span>'
                    return
                if not saved:
                    hint = '，'.join([
                        'local.keystore', 'localTrust.keystore', 'collection.cer', 'appPrivateKey.pfx'
                    ])
                    status.value = (
                        '<span style="color:#c00">未识别到可保存的文件名，请确保文件名与要求一致</span>'
                        f'<br/>期待文件名：{hint}'
                        + (f'<br/>收到：{", ".join([str(u) for u in unknown])}' if unknown else '')
                    )
                    return
                status.value = '<span style="color:#070">保存成功：</span><br/>' + '<br/>'.join(saved)
            except Exception as e:
                status.value = f'<span style=\"color:#c00\">保存失败：{e}</span>'

        save_btn.on_click(_save_clicked)
        box = widgets.VBox([title, prefix_input, uploader, save_btn, status])
        display(box)
    except Exception:
        # Ignore UI errors silently
        pass


def _auto_check_certs_on_import() -> None:
    try:
        if not _any_cert_layout_present() and _is_jupyter_environment():
            _show_cert_upload_dialog()
    except Exception:
        pass


# Trigger on import (only in Jupyter and when layout missing)
_auto_check_certs_on_import()


def open_config_wizard(prefix: str) -> None:
    """In Jupyter, render a minimal wizard to create <cwd>/<prefix>/sdk.config.json."""
    try:
        import ipywidgets as widgets  # type: ignore
        from IPython.display import display  # type: ignore
        import json as _json
        from pathlib import Path

        title = widgets.HTML(
            value='<h3 style="font-family:ui-sans-serif; margin:4px 0 8px">Handle 配置向导</h3>'
        )
        ip = widgets.Text(description='IP', placeholder='例如 112.124.70.83', layout=widgets.Layout(width='50%'))
        port = widgets.IntText(description='Port', value=8443, layout=widgets.Layout(width='30%'))
        ks = widgets.Password(description='keystore', placeholder='ssl_keystore_password')
        ts = widgets.Password(description='truststore', placeholder='ssl_truststore_password')
        appid = widgets.Text(description='appHandleId', placeholder='86.5000/xxxx')
        appkey = widgets.Password(description='appKeyPwd', placeholder='应用证书密码')
        verify = widgets.Password(description='verifyPwd', placeholder='验证密码')
        save = widgets.Button(description='生成 sdk.config.json', button_style='primary')
        status = widgets.HTML(value='')

        def _save(_):
            base = Path(os.getcwd()) / prefix
            base.mkdir(parents=True, exist_ok=True)
            cfg = {
                'ip': ip.value.strip(),
                'port': int(port.value),
                'ssl_keystore_password': ks.value,
                'ssl_truststore_password': ts.value,
                'app_handle_id': appid.value.strip(),
                'app_key_pwd': appkey.value,
                'app_verify_password': verify.value,
            }
            req = ['ip','ssl_keystore_password','ssl_truststore_password','app_handle_id','app_key_pwd','app_verify_password']
            if any(not cfg[k] for k in req):
                status.value = '<span style="color:#c00">请完整填写必填项</span>'
                return
            with open(base / 'sdk.config.json', 'w', encoding='utf-8') as f:
                _json.dump(cfg, f, ensure_ascii=False, indent=2)
            status.value = '<span style="color:#070">已生成配置文件：{}/sdk.config.json</span>'.format(prefix)

        save.on_click(_save)
        display(widgets.VBox([title, ip, port, ks, ts, appid, appkey, verify, save, status]))
    except Exception:
        pass
